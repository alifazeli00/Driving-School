﻿using CodeYad_Blog.CoreLayer.Utilities;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace app.User.queriea
{
    public class FindpassDto
    {
        public string phone { get; set; }
    }
    public class FindeUserQuerie:IRequest<string>
    {
        public FindpassDto FindpassDto { get; set; }
        public FindeUserQuerie(FindpassDto FindpassDto)
        {
            this.FindpassDto = FindpassDto;

        }
    }

    public class FindeUserQuerieHandler : IRequestHandler<FindeUserQuerie, string>
    {
        private readonly IDataBaceContext context;

        public FindeUserQuerieHandler(IDataBaceContext context)
        {
            this.context = context;
        }

        public Task<string> Handle(FindeUserQuerie request, CancellationToken cancellationToken)
        {
            var res = context.Users.Where(p => p.phone == request.FindpassDto.phone).FirstOrDefault();
          var pas=  res.Pass.EncodeToMd5();
            return Task.FromResult(pas);


        }
    }
}
