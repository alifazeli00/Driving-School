﻿using System;

namespace app
{
    public class Class1
    {
    }
}
